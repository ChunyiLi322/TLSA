# lm_challenges
http://www.mys5.org/Proceedings/2016/Day_2/2016-S5-Day2_0945_Elliott.pdf

Copyright 2016, Lockheed Martin Corporation. All rights reserved
